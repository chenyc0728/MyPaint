#include "canvas.h"

Canvas::Canvas(QWidget *parent) :
    QWidget(parent)
{
    this->setStyleSheet("background-color:white;");
}
